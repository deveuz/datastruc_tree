
import com.sun.media.jfxmedia.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Vera Kim Tequin
 */
public class BinaryTree {
    
    BinaryTreeNode root;
  
    BinaryTree(){ root = null;  }
    BinaryTree(BinaryTreeNode r) {  root = r;  }
    
 
    
    public void InOrder(BinaryTreeNode t){       
        if (t != null)  {
            InOrder(t.getLeftTree());
             System.out.print(t.getData());
            InOrder(t.getRightTree());
        }
    }
    
     public void PostOrder(BinaryTreeNode t){
        if (t != null)
        {
            PostOrder(t.getLeftTree());
            PostOrder(t.getRightTree());
            System.out.print(t.getData());
        }
    }
     
     public void PreOrder(BinaryTreeNode t){
        if (t != null)
        {
            System.out.print(t.getData());
            PreOrder(t.getLeftTree());
            PreOrder(t.getRightTree());
        }
     }
     
     
       public void InOrder_toChar(BinaryTreeNode t){       
        if (t != null)  {
            InOrder_toChar(t.getLeftTree());
             System.out.print((char)t.getData());
            InOrder_toChar(t.getRightTree());
        }
    }
    
     public void PostOrder_toChar(BinaryTreeNode t){
        if (t != null)
        {
            PostOrder_toChar(t.getLeftTree());
            PostOrder_toChar(t.getRightTree());
            System.out.print((char)t.getData());
        }
    }
     
     public void PreOrder_toChar(BinaryTreeNode t){
        if (t != null)
        {
            System.out.print((char)t.getData());
            PreOrder_toChar(t.getLeftTree());
            PreOrder_toChar(t.getRightTree());
        }
     }
     
     
     
     public BinaryTreeNode getRoot(){
        return root;
        
    }
    
     public int getHeight(BinaryTreeNode bt){
        if(bt == null)
            return -1;
        else
            return 1 + Math.max(getHeight(bt.getLeftTree()),getHeight(bt.getRightTree()));
    }
    

    
  
    public void setRoot(BinaryTreeNode r){
        root=r;
    }


}
