/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vera Kim Tequin
 */
public class BSTApp {
    public static void main(String args[]){
        
        BinaryTreeNode root = new BinaryTreeNode(13);
        BinarySearchTree BST = new BinarySearchTree(root);
        
        BST.insert(root, new BinaryTreeNode(10));
        BST.insert(root, new BinaryTreeNode(9));
        BST.insert(root, new BinaryTreeNode(15));
        BST.insert(root, new BinaryTreeNode(17));
        
        BST.insert(root, new BinaryTreeNode(21));
        BST.insert(root, new BinaryTreeNode(3));
        BST.insert(root, new BinaryTreeNode(5));
        BST.insert(root, new BinaryTreeNode(8));
        
        BST.insert(root, new BinaryTreeNode(18));
    
        
        
        System.out.print("In-order: "); BST.InOrder(root); 
        System.out.print("\nPre-order: "); BST.PreOrder(root); 
        System.out.print("\nPost-order: ");BST.PostOrder(root);
        
        System.out.println("\nMinimum is "+BST.findMin(BST.getRoot()));
        System.out.println("Maximum is "+BST.findMax(BST.getRoot()));
        System.out.println("Height is "+BST.getHeight(BST.getRoot()));
        
        
      //  BST.remove(root);
      //  System.out.print("In-order: "); BST.InOrder(root); 
        
        BinaryTreeNode node = new BinaryTreeNode(1);
       
        System.out.println("Found? true/false: "+ BST.isFound(node, root));
        
     //   BinaryTreeNode Temp = BST.searchNode(node, root);
        
       // System.out.println("Temp is:  "+ Temp+ "; left is: "+Temp.getLeftTree()+
         //       "; right is: "+Temp.getRightTree());
        
   //     BST.remove(Temp,root);
        System.out.print("In-order: "); BST.InOrder(root); 
    }
    
    
    
}
