import java.util.Scanner;

public class BSTInterface {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BinarySearchTree bst = new BinarySearchTree();
        
        while (true) {
            System.out.println("\n=== Binary Search Tree Interface ===");
            System.out.println("InOrder: ");
            bst.InOrder(bst.getRoot());
            System.out.println("\n\nPreOrder: ");
            bst.PreOrder(bst.getRoot());
            System.out.println("\n\nPostOrder: ");
            bst.PostOrder(bst.getRoot());
            
            System.out.println("\n\nMin: " + (bst.findMin(bst.getRoot()) != null ? bst.findMin(bst.getRoot()).getData() : "N/A"));
            System.out.println("Max: " + (bst.findMax(bst.getRoot()) != null ? bst.findMax(bst.getRoot()).getData() : "N/A"));
            System.out.println("Height: " + bst.getHeight(bst.getRoot()));
            
            System.out.println("\n(I)NSERT (S)EARCH (R)EMOVE E(X)IT");
            System.out.print("\nEnter choice: ");
            
            String choice = scanner.nextLine().toUpperCase();
            
            switch (choice) {
                case "I":
                    System.out.print("Enter value to insert: ");
                    try {
                        int value = Integer.parseInt(scanner.nextLine());
                        if (bst.getRoot() == null) {
                            bst.setRoot(new BinaryTreeNode(value));
                        } else {
                            bst.insert(bst.getRoot(), new BinaryTreeNode(value));
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Please enter a valid number");
                    }
                    break;
                    
                case "S":
                    System.out.print("Enter value to search: ");
                    try {
                        int value = Integer.parseInt(scanner.nextLine());
                        boolean found = bst.isFound(new BinaryTreeNode(value), bst.getRoot());
                        System.out.println(found ? "Found!" : "Not found!");
                    } catch (NumberFormatException e) {
                        System.out.println("Please enter a valid number");
                    }
                    break;
                    
                case "R":
                    System.out.print("Enter value to remove: ");
                    try {
                        int value = Integer.parseInt(scanner.nextLine());
                        BinaryTreeNode nodeToRemove = new BinaryTreeNode(value);
                        if (bst.isFound(nodeToRemove, bst.getRoot())) {
                            bst.setRoot(bst.remove(nodeToRemove, bst.getRoot()));
                            System.out.println("Value removed successfully!");
                        } else {
                            System.out.println("Value not found in the tree!");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Please enter a valid number");
                    }
                    break;
                    
                case "X":
                    System.out.println("Goodbye!");
                    scanner.close();
                    return;
                    
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
} 