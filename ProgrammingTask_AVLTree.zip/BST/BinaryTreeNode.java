/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Vera Kim Tequin
 */
public class BinaryTreeNode {
    int data;
    BinaryTreeNode leftTree;
    BinaryTreeNode rightTree;

    public BinaryTreeNode() {
        data=0;
        leftTree = null;
        rightTree = null;
    }

    
    public BinaryTreeNode(int data, BinaryTreeNode leftTree, BinaryTreeNode rightTree) {
        this.data = data;
        this.leftTree = leftTree;
        this.rightTree = rightTree;
    }

    public BinaryTreeNode(int data) {
        this.data = data;
        leftTree=null;
        rightTree=null;
    }

    public void setData(int data) {
        this.data = data;
    }

    public void setLeftTree(BinaryTreeNode leftTree) {
        this.leftTree = leftTree;
    }

    public void setRightTree(BinaryTreeNode rightTree) {
        this.rightTree = rightTree;
    }

    public int getData() {
        return data;
    }

    public BinaryTreeNode getLeftTree() {
        return leftTree;
    }

    public BinaryTreeNode getRightTree() {
        return rightTree;
    }
    
    public boolean equals(BinaryTreeNode n){
        return (this.data == n.getData());
    }
    @Override
    public String toString() {
        return "BinaryTreeNode{" + "data=" + data + '}';
    }
    
}
