import java.util.Scanner;

public class TreeInterface {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Select tree type:");
        System.out.println("1. Binary Search Tree");
        System.out.println("2. AVL Tree");
        System.out.print("\nEnter choice (1 or 2): ");
        
        BinaryTree tree = null;
        String treeType = "Binary Search Tree";  // Default type name
        
        try {
            int treeChoice = Integer.parseInt(scanner.nextLine());
            if (treeChoice == 1) {
                tree = new BinarySearchTree();
                treeType = "Binary Search Tree";
            } else if (treeChoice == 2) {
                tree = new AVLTree();
                treeType = "AVL Tree";
            } else {
                System.out.println("Invalid choice. Defaulting to BST.");
                tree = new BinarySearchTree();
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Defaulting to BST.");
            tree = new BinarySearchTree();
        }
        
        while (true) {
            System.out.println("\n=== " + treeType + " Interface ===");
            System.out.println("InOrder: ");
            tree.InOrder(tree.getRoot());
            System.out.println("\nPreOrder: ");
            tree.PreOrder(tree.getRoot());
            System.out.println("\nPostOrder: ");
            tree.PostOrder(tree.getRoot());
            
            if (tree instanceof BinarySearchTree) {
                BinarySearchTree bst = (BinarySearchTree) tree;
                System.out.println("\nMin: " + (bst.findMin(bst.getRoot()) != null ? bst.findMin(bst.getRoot()).getData() : "N/A"));
                System.out.println("Max: " + (bst.findMax(bst.getRoot()) != null ? bst.findMax(bst.getRoot()).getData() : "N/A"));
            }
            System.out.println("Height: " + tree.getHeight(tree.getRoot()));
            
            System.out.println("\n(I)NSERT (S)EARCH (R)EMOVE E(X)IT");
            System.out.print("\nEnter choice: ");
            
            String choice = scanner.nextLine().toUpperCase();
            
            switch (choice) {
                case "I":
                    System.out.print("Enter value to insert: ");
                    try {
                        int value = Integer.parseInt(scanner.nextLine());
                        BinaryTreeNode newNode = new BinaryTreeNode(value);
                        if (tree.getRoot() == null) {
                            tree.setRoot(newNode);
                        } else if (tree instanceof AVLTree) {
                            tree.setRoot(((AVLTree) tree).insert(tree.getRoot(), newNode));
                        } else {
                            ((BinarySearchTree) tree).insert(tree.getRoot(), newNode);
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Please enter a valid number");
                    }
                    break;
                    
                case "S":
                    if (tree instanceof BinarySearchTree) {
                        System.out.print("Enter value to search: ");
                        try {
                            int value = Integer.parseInt(scanner.nextLine());
                            boolean found = ((BinarySearchTree) tree).isFound(new BinaryTreeNode(value), tree.getRoot());
                            System.out.println(found ? "Found!" : "Not found!");
                        } catch (NumberFormatException e) {
                            System.out.println("Please enter a valid number");
                        }
                    }
                    break;
                    
                case "R":
                    if (tree instanceof BinarySearchTree) {
                        System.out.print("Enter value to remove: ");
                        try {
                            int value = Integer.parseInt(scanner.nextLine());
                            BinaryTreeNode nodeToRemove = new BinaryTreeNode(value);
                            if (((BinarySearchTree) tree).isFound(nodeToRemove, tree.getRoot())) {
                                if (tree instanceof AVLTree) {
                                    tree.setRoot(((AVLTree) tree).remove(nodeToRemove, tree.getRoot()));
                                } else {
                                    tree.setRoot(((BinarySearchTree) tree).remove(nodeToRemove, tree.getRoot()));
                                }
                                System.out.println("Value removed successfully!");
                            } else {
                                System.out.println("Value not found in the tree!");
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Please enter a valid number");
                        }
                    }
                    break;
                    
                case "X":
                    scanner.close();
                    return;
                    
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
} 