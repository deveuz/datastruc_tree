public class AVLTree extends BinarySearchTree {
    
    AVLTree() {
        super();
    }
    
    AVLTree(BinaryTreeNode r) {
        super(r);
    }
    
    private int getBalance(BinaryTreeNode node) {
        if (node == null) return 0;
        return getHeight(node.getLeftTree()) - getHeight(node.getRightTree());
    }
    
    private BinaryTreeNode rightRotate(BinaryTreeNode y) {
        BinaryTreeNode x = y.getLeftTree();
        BinaryTreeNode T2 = x.getRightTree();
        
        x.setRightTree(y);
        y.setLeftTree(T2);
        
        return x;
    }
    
    private BinaryTreeNode leftRotate(BinaryTreeNode x) {
        BinaryTreeNode y = x.getRightTree();
        BinaryTreeNode T2 = y.getLeftTree();
        
        y.setLeftTree(x);
        x.setRightTree(T2);
        
        return y;
    }
    
    @Override
    public BinaryTreeNode insert(BinaryTreeNode node, BinaryTreeNode newNode) {
        // 1. Perform normal BST insertion
        if (node == null) return newNode;
        
        if (newNode.getData() < node.getData())
            node.setLeftTree(insert(node.getLeftTree(), newNode));
        else if (newNode.getData() > node.getData())
            node.setRightTree(insert(node.getRightTree(), newNode));
        else // Duplicate keys not allowed
            return node;
            
        // 2. Get the balance factor
        int balance = getBalance(node);
        
        // Left Left Case
        if (balance > 1 && newNode.getData() < node.getLeftTree().getData())
            return rightRotate(node);
            
        // Right Right Case
        if (balance < -1 && newNode.getData() > node.getRightTree().getData())
            return leftRotate(node);
            
        // Left Right Case
        if (balance > 1 && newNode.getData() > node.getLeftTree().getData()) {
            node.setLeftTree(leftRotate(node.getLeftTree()));
            return rightRotate(node);
        }
        
        // Right Left Case
        if (balance < -1 && newNode.getData() < node.getRightTree().getData()) {
            node.setRightTree(rightRotate(node.getRightTree()));
            return leftRotate(node);
        }
        
        return node;
    }
    
    @Override
    public BinaryTreeNode remove(BinaryTreeNode node, BinaryTreeNode root) {
        // 1. Perform standard BST delete
        if (root == null) return null;
        
        if (node.getData() < root.getData())
            root.setLeftTree(remove(node, root.getLeftTree()));
        else if (node.getData() > root.getData())
            root.setRightTree(remove(node, root.getRightTree()));
        else {
            // node with only one child or no child
            if (root.getLeftTree() == null || root.getRightTree() == null) {
                BinaryTreeNode temp = null;
                if (temp == root.getLeftTree())
                    temp = root.getRightTree();
                else
                    temp = root.getLeftTree();
                
                if (temp == null) {
                    temp = root;
                    root = null;
                } else
                    root = temp;
            } else {
                // node with two children: Get the inorder successor (smallest
                // in the right subtree)
                BinaryTreeNode temp = findMin(root.getRightTree());
                root.setData(temp.getData());
                root.setRightTree(remove(temp, root.getRightTree()));
            }
        }
        
        // If the tree had only one node then return
        if (root == null) return null;
        
        // 2. Update balance factor and rotate if needed
        int balance = getBalance(root);
        
        // Left Left Case
        if (balance > 1 && getBalance(root.getLeftTree()) >= 0)
            return rightRotate(root);
            
        // Left Right Case
        if (balance > 1 && getBalance(root.getLeftTree()) < 0) {
            root.setLeftTree(leftRotate(root.getLeftTree()));
            return rightRotate(root);
        }
        
        // Right Right Case
        if (balance < -1 && getBalance(root.getRightTree()) <= 0)
            return leftRotate(root);
            
        // Right Left Case
        if (balance < -1 && getBalance(root.getRightTree()) > 0) {
            root.setRightTree(rightRotate(root.getRightTree()));
            return leftRotate(root);
        }
        
        return root;
    }
} 