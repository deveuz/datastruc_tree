/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vera Kim Tequin
 */
public class BinarySearchTree extends BinaryTree {
    
    BinarySearchTree(){
        super();        
    }
    
    BinarySearchTree(BinaryTreeNode r){
        super(r);       
    }
    
    public BinaryTreeNode insert(BinaryTreeNode t, BinaryTreeNode newNode){
    
        if(t==null) {t=newNode; return t;}           
        else if(t.getData() > newNode.getData()) t.setLeftTree(insert(t.getLeftTree(),newNode));
        else if(t.getData() < newNode.getData()) t.setRightTree(insert(t.getRightTree(),newNode));      
        return t;
    }
    
    public BinaryTreeNode findMin(BinaryTreeNode t){
        if(t==null) return null;
        else if(t.getLeftTree()==null) return t;
        return findMin(t.getLeftTree());
    
    }
    
    public BinaryTreeNode findMax(BinaryTreeNode t){
        if(t==null) return null;
        else if(t.getRightTree()==null) return t;
        return findMax(t.getRightTree());
    
    }
    
  //  @Override
      public boolean isFound(BinaryTreeNode node, BinaryTreeNode t){     
        return ((searchNode(node,t) != null ));
     }
      
   // @Override
       public BinaryTreeNode searchNode(BinaryTreeNode node, BinaryTreeNode t){
       
        if (t==null) return null;
   
        if(node.getData() < t.getData()) return searchNode(node,t.getLeftTree());
        else if (node.getData() > t.getData()) return searchNode(node, t.getRightTree());
        else return t;
        
     }   
    
    public BinaryTreeNode remove(BinaryTreeNode node, BinaryTreeNode t) {
        if (t == null) return null;
        
        if (node.getData() < t.getData())
            t.setLeftTree(remove(node, t.getLeftTree()));
        else if (node.getData() > t.getData())
            t.setRightTree(remove(node, t.getRightTree()));
        else {
            // Node with only one child or no child
            if (t.getLeftTree() == null)
                return t.getRightTree();
            else if (t.getRightTree() == null)
                return t.getLeftTree();
                
            // Node with two children: Get the inorder successor (smallest
            // in the right subtree)
            BinaryTreeNode temp = findMin(t.getRightTree());
            t.setData(temp.getData());
            t.setRightTree(remove(temp, t.getRightTree()));
        }
        return t;
    }
}
