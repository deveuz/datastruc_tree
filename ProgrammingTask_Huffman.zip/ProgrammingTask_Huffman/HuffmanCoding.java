import java.util.*;

public class HuffmanCoding {
    private static Map<Character, String> huffmanCodes = new HashMap<>();
    private static HuffmanNode root;

    private static HuffmanNode buildHuffmanTree(String text) {
        // Count frequency of characters
        Map<Character, Integer> freq = new HashMap<>();
        for (char c : text.toCharArray()) {
            freq.put(c, freq.getOrDefault(c, 0) + 1);
        }

        // Create priority queue
        PriorityQueue<HuffmanNode> pq = new PriorityQueue<>();
        for (Map.Entry<Character, Integer> entry : freq.entrySet()) {
            pq.offer(new HuffmanNode(entry.getKey(), entry.getValue()));
        }

        // Build Huffman Tree
        while (pq.size() > 1) {
            HuffmanNode left = pq.poll();
            HuffmanNode right = pq.poll();
            HuffmanNode parent = new HuffmanNode('\0', left.frequency + right.frequency);
            parent.left = left;
            parent.right = right;
            pq.offer(parent);
        }

        return pq.poll();
    }

    private static void generateCodes(HuffmanNode node, String code) {
        if (node == null) return;
        
        if (node.left == null && node.right == null) {
            huffmanCodes.put(node.character, code);
            return;
        }

        generateCodes(node.left, code + "0");
        generateCodes(node.right, code + "1");
    }

    private static String encode(String text) {
        StringBuilder encoded = new StringBuilder();
        for (char c : text.toCharArray()) {
            encoded.append(huffmanCodes.get(c));
        }
        return encoded.toString();
    }

    private static String decode(String encoded) {
        StringBuilder decoded = new StringBuilder();
        HuffmanNode current = root;
        
        for (char bit : encoded.toCharArray()) {
            if (bit == '0') {
                current = current.left;
            } else {
                current = current.right;
            }

            if (current.left == null && current.right == null) {
                decoded.append(current.character);
                current = root;
            }
        }
        
        return decoded.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        char choice;
        
        do {
            // Clear huffmanCodes for new message
            huffmanCodes.clear();
            
            System.out.print("Enter message: ");
            String message = scanner.nextLine();
            
            // Build Huffman tree and generate codes
            root = buildHuffmanTree(message);
            generateCodes(root, "");
            
            // Encode message
            String encoded = encode(message);
            System.out.println("\nCoded message in bits: " + encoded);
            
            // Decode message
            String decoded = decode(encoded);
            System.out.println("\nDecoded message: " + decoded);
            
            // Calculate and display bit sizes
            int asciiSize = message.length() * 8;
            int huffmanSize = encoded.length();
            
            System.out.println("\nNumber of bits of the message in ASCII: " + asciiSize);
            System.out.println("Number of bits of the message using Huffman Tree: " + huffmanSize);
            
            System.out.print("\nDo you want to enter another message? (y/n): ");
            choice = scanner.nextLine().toLowerCase().charAt(0);
            System.out.println(); // Add blank line for readability
            
        } while (choice == 'y');
        
        scanner.close();
        System.out.println("Goodbye!");
    }
} 